package assistedPractice3;

import java.util.Scanner;

public class MatrixMultiplication {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.println("Enter the number of rows for the first matrix:");
        int rowsA = scanner.nextInt();
        System.out.println("Enter the number of columns for the first matrix (and rows for the second):");
        int colsA_rowsB = scanner.nextInt(); 
     
        int[][] matrixA = new int[rowsA][colsA_rowsB];
        System.out.println("Enter the elements for the first matrix:");
        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsA_rowsB; j++) {
                matrixA[i][j] = scanner.nextInt();
            }
        }

       
        System.out.println("Enter the number of columns for the second matrix:");
        int colsB = scanner.nextInt();


        int[][] matrixB = new int[colsA_rowsB][colsB];
        System.out.println("Enter the elements for the second matrix:");
        for (int i = 0; i < colsA_rowsB; i++) {
            for (int j = 0; j < colsB; j++) {
                matrixB[i][j] = scanner.nextInt();
            }
        }

        
        int[][] product = new int[rowsA][colsB];
        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsB; j++) {
                for (int k = 0; k < colsA_rowsB; k++) {
                    product[i][j] += matrixA[i][k] * matrixB[k][j];
                }
            }
        }

       
        System.out.println("Product of the two matrices is:");
        for (int[] row : product) {
            for (int column : row) {
                System.out.print(column + " ");
            }
            System.out.println();
        }
    }
}
