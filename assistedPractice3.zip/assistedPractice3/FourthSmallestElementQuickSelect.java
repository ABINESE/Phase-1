package assistedPractice3;

import java.util.Scanner;

public class FourthSmallestElementQuickSelect {
	 private static int partition(int[] arr, int low, int high) {
	        int pivot = arr[high];
	        int i = low;
	        for (int j = low; j < high; j++) {
	            if (arr[j] <= pivot) {
	               
	                int temp = arr[i];
	                arr[i] = arr[j];
	                arr[j] = temp;
	                i++;
	            }
	        }
	     
	        int temp = arr[i];
	        arr[i] = arr[high];
	        arr[high] = temp;
	        
	        return i;
	    }

	    
	    private static int quickSelect(int[] arr, int low, int high, int k) {
	        
	        if (low == high) {
	            return arr[low];
	        }
	        
	        int partitionIndex = partition(arr, low, high);
	        
	        
	        int length = partitionIndex - low + 1;
	        
	      
	        if (length == k) {
	            return arr[partitionIndex];
	        } else if (k < length) {
	          
	            return quickSelect(arr, low, partitionIndex - 1, k);
	        } else {
	          
	            return quickSelect(arr, partitionIndex + 1, high, k - length);
	        }
	    }

	    public static void main(String[] args) {
	    	
	        	Scanner scanner=new Scanner(System.in);
	            System.out.println("Enter the Number of elements in array");
	            int n= scanner.nextInt();
	            int arr[]=new int[n];
	            System.out.println("Enter  elements in array");
	            for(int i=0;i<n;i++)
	            {
	            	arr[i]=scanner.nextInt();
	            }
	        
	        System.out.println("The fourth smallest element is: " + quickSelect(arr, 0, arr.length - 1, 4));
	    }
}
