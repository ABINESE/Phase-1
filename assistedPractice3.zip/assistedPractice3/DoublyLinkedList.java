package assistedPractice3;

class DoublyLinkedList {
    Node head; 

    
    class Node {
        int data;
        Node prev;
        Node next;

        
        Node(int d) { data = d; }
    }

    public void append(int newData) {
        Node newNode = new Node(newData);
        Node last = head; 

       
        if (head == null) {
            newNode.prev = null;
            head = newNode;
            return;
        }

       while (last.next != null) {
            last = last.next;
        }

        
        last.next = newNode;

        
        newNode.prev = last;
    }

    
    public void printListForward() {
        Node temp = head;
        System.out.print("Traversal in forward Direction: ");
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    
    public void printListBackward() {
        Node temp = head;
        System.out.print("Traversal in backward Direction: ");
       
        while (temp.next != null) {
            temp = temp.next;
        }
       
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.prev;
        }
        System.out.println();
    }



    public static void main(String[] args) {
        DoublyLinkedList dll = new DoublyLinkedList();

        
        dll.append(10);
        dll.append(20);
        dll.append(30);
        dll.append(40);
        dll.append(50);

        
        dll.printListForward();

        
        dll.printListBackward();
    }
}
