package assistedPractice3;

class Stack {
    private int[] arr;
    private int top;
    private int capacity;

    Stack(int size) {
        arr = new int[size];
        capacity = size;
        top = -1;
    }

   
    public void push(int x) {
        if (isFull()) {
            System.out.println("Stack Overflow");
            System.exit(1);
        }
        System.out.println("Inserting " + x);
        arr[++top] = x;
    }

        public int pop() {
        if (isEmpty()) {
            System.out.println("STACK EMPTY");
            System.exit(1);
        }
        return arr[top--];
    }


    public int size() {
        return top + 1;
    }

    
    public Boolean isEmpty() {
        return top == -1;
    }

  
    public Boolean isFull() {
        return top == capacity - 1;
    }

    
    public static void main(String[] args) {
        Stack stack = new Stack(5);

        stack.push(1);
        stack.push(2);
        stack.push(3);

        System.out.println("The top element is " + stack.pop());
        System.out.println("The stack size is " + stack.size());

        stack.push(4);

        System.out.println("The stack is empty: " + stack.isEmpty());
        System.out.println("The stack is full: " + stack.isFull());
    }
}
