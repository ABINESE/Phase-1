package assistedPractice3;

import java.util.Scanner;

public class ArrayElementsMoving {
	public static void rightRotate(int[] arr, int n) {
        int length = arr.length;
        n = n % length;
        int[] temp = new int[n];
        
        
        for (int i = 0; i < n; i++) {
            temp[i] = arr[length - n + i];
        }
        
        
        for (int i = length - 1; i >= n; i--) {
            arr[i] = arr[i - n];
        }
        
        
        for (int i = 0; i < n; i++) {
            arr[i] = temp[i];
        }
    }
    
    
    public static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
        System.out.println("Enter the Number of elements in array");
        int N= scanner.nextInt();
        int arr[]=new int[N];
        System.out.println("Enter  elements in array");
        for(int i=0;i<N;i++)
        {
        	arr[i]=scanner.nextInt();
        }
        rightRotate(arr,  5);
        printArray( arr);
	}

}
