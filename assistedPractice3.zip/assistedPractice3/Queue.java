package assistedPractice3;

class Queue {
    private int[] arr;
    private int front;
    private int rear;
    private int capacity;
    private int count;

    Queue(int size) {
        arr = new int[size];
        capacity = size;
        front = 0;
        rear = -1;
        count = 0;
    }

    
    public void enqueue(int item) {
        if (isFull()) {
            System.out.println("Queue Overflow");
            System.exit(1);
        }
        System.out.println("Enqueuing " + item);
        rear = (rear + 1) % capacity;
        arr[rear] = item;
        count++;
    }

    
    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Queue Underflow");
            System.exit(1);
        }
        int item = arr[front];
        front = (front + 1) % capacity;
        count--;
        return item;
    }

    public boolean isEmpty() {
        return (count == 0);
    }

   
    public boolean isFull() {
        return (count == capacity);
    }


    public int peek() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            System.exit(1);
        }
        return arr[front];
    }

    
    public static void main(String[] args) {
        Queue queue = new Queue(5);

        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);
        queue.enqueue(4);

        System.out.println("The front element is: " + queue.peek());
        
        queue.dequeue();
        queue.dequeue();
        
        System.out.println("After two dequeues, the front element is: " + queue.peek());
        
        queue.enqueue(5);

        while (!queue.isEmpty()) {
            System.out.println("Dequeueing: " + queue.dequeue());
        }
    }
}
