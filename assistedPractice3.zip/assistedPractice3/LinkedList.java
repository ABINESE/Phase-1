package assistedPractice3;

class LinkedList {
    Node head; 
    
    
    class Node {
        int data;
        Node next;
        
        Node(int d) {
            data = d;
            next = null;
        }
    }
    
    
    public void append(int new_data) {
        Node new_node = new Node(new_data);
        
        if (head == null) {
            head = new Node(new_data);
            return;
        }
        
        new_node.next = null;
        
        Node last = head; 
        while (last.next != null) {
            last = last.next;
        }
        
        last.next = new_node;
        return;
    }
    
    
   
    public void deleteKey(int key) {
        Node temp = head, prev = null;
        
        
        if (temp != null && temp.data == key) {
            head = temp.next; 
            return;
        }
        
       
        while (temp != null && temp.data != key) {
            prev = temp;
            temp = temp.next;
        }
        
       
        if (temp == null) return;
        
        
        prev.next = temp.next;
    }
    
   
    public void printList() {
        Node tnode = head;
        while (tnode != null) {
            System.out.print(tnode.data + " ");
            tnode = tnode.next;
        }
    }
    
    public static void main(String[] args) {
        LinkedList llist = new LinkedList();
        
        llist.append(1);
        llist.append(2);
        llist.append(3);
        llist.append(4);
        llist.append(2);
        llist.append(5);
        
        System.out.println("Created Linked list is:");
        llist.printList();
        
        int keyToDelete = 2;
        llist.deleteKey(keyToDelete); 
        System.out.println("\nLinked List after Deletion of " + keyToDelete + ":");
        llist.printList();
    }
}