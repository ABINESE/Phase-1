package assistedPractice3;

class SortedCircularLinkedList {
    Node head = null;
    
    class Node {
        int data;
        Node next;
        
        Node(int data) {
            this.data = data;
            this.next = this; 
        }
    }
    
    
    public void sortedInsert(int data) {
        Node newNode = new Node(data);
        
        
        if (head == null) {
            head = newNode;
        } else if (data <= head.data) {
            
            Node last = head;
            while (last.next != head) {
                last = last.next;
            }
            
            newNode.next = head;
            head = newNode;
            last.next = head; 
        } else {
            
            Node current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            
            newNode.next = current.next;
            current.next = newNode;
        }
    }
    
    
    public void printList() {
        if (head != null) {
            Node temp = head;
            do {
                System.out.print(temp.data + " ");
                temp = temp.next;
            } while (temp != head);
            System.out.println();
        }
    }
    
    public static void main(String[] args) {
        SortedCircularLinkedList list = new SortedCircularLinkedList();
        
        
        list.sortedInsert(40);
        list.sortedInsert(20);
        list.sortedInsert(50);
        list.sortedInsert(10);
        list.sortedInsert(30);
        
        System.out.println("Sorted Circular Linked List:");
        list.printList();
    }
}
