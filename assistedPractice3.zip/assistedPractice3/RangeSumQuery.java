package assistedPractice3;

import java.util.Scanner;

public class RangeSumQuery {
	 private static int[] prefixSum(int[] arr) {
	        int n = arr.length;
	        int[] prefixSum = new int[n];
	        prefixSum[0] = arr[0];
	        for (int i = 1; i < n; i++) {
	            prefixSum[i] = prefixSum[i - 1] + arr[i];
	        }
	        return prefixSum;
	    }

	  
	    private static int rangeSum(int[] prefixSum, int L, int R) {
	        if (L == 0) {
	            return prefixSum[R];
	        }
	        return prefixSum[R] - prefixSum[L - 1];
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        
	        System.out.print("Enter the number of elements in the array: ");
	        int n = scanner.nextInt();
	        int[] arr = new int[n];

	        
	        System.out.println("Enter the array elements:");
	        for (int i = 0; i < n; i++) {
	            arr[i] = scanner.nextInt();
	        }

	        // Input L and R
	        System.out.print("Enter L (start index of the range): ");
	        int L = scanner.nextInt();
	        System.out.print("Enter R (end index of the range): ");
	        int R = scanner.nextInt();

	        
	        if (L < 0 || R >= n || L > R) {
	            System.out.println("Invalid range. Please ensure that 0 <= L <= R <= n-1.");
	            return;
	        }

	       
	        int[] prefixSum = prefixSum(arr);

	        
	        System.out.println("The sum of elements in the range [" + L + ", " + R + "] is: " + rangeSum(prefixSum, L, R));
	    }
}
