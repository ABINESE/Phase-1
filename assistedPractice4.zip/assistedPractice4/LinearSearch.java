package assistedPractice4;
import java.util.ArrayList;
import java.util.Scanner;
public class LinearSearch {
public static void main(String[] args)
{
	Scanner scanner=new Scanner(System.in);
	ArrayList<String> arr= new ArrayList<>();
	System.out.print("Enter the elements");
	while(true)
	{
		String str=scanner.next();
		if(str.equalsIgnoreCase("exit"))
			break;
		arr.add(str);
	}
	System.out.print("Enter searching elements");
	String input=scanner.next();
boolean present=false;
	for(String st:arr)
	{
		if(st.contains(input))
			present=true;
	}
	if(present)
		System.out.print(input+"is present in the given array");
	else
		System.out.print(input+" is not present in the given array");
}
}
