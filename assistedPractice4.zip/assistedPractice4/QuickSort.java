package assistedPractice4;

import java.util.Scanner;

public class QuickSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.print("Enter the number of elements");
		int n=scanner.nextInt();
		int[] arr=new int[n];
		System.out.print("Enter the elements");
		for(int i=0;i<n;i++)
		{
			arr[i]=scanner.nextInt();
		}
		Sort(arr,0,arr.length-1);
		System.out.print("Sorted arrays\n");
		for(int i=0;i<n;i++)
		{
			System.out.println(arr[i]);
			
		}
	}

	private static void Sort(int[] arr, int l, int h) {
		// TODO Auto-generated method stub
		if(l<h)
		{
			int p=partition(arr,l, h);
			Sort(arr,l,p-1);
			Sort(arr,p+1,h);
			
		}
	}

	private static int partition(int[] arr, int l, int h) {
		// TODO Auto-generated method stub
		int pivot=arr[h];
		int i=l-1;
		for(int j=l;j<=h-1;j++)
		{
			if(arr[j]<=pivot)
			{
				i++;
				int temp=arr[j];
				arr[j]=arr[i];
				arr[i]=temp;
			}
		}
		i++;
		int temp=arr[i];
		arr[i]=arr[h];
		arr[h]=temp;
		return i;
	}

}
