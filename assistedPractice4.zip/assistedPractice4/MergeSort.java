package assistedPractice4;

import java.util.Scanner;

public class MergeSort {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner=new Scanner(System.in);
		System.out.print("Enter the number of elements");
		int n=scanner.nextInt();
		int[] arr=new int[n];
		System.out.print("Enter the elements");
		for(int i=0;i<n;i++)
		{
			arr[i]=scanner.nextInt();
		}
		Sort(arr,0,arr.length-1);
		System.out.print("Sorted arrays\n");
		for(int i=0;i<n;i++)
		{
			System.out.println(arr[i]);
		}
}

	private static void Sort(int[] arr, int low, int high) {
		// TODO Auto-generated method stub
		if(low<high)
		{
			int mid=(low+high)/2;
			Sort(arr,low,mid);
			Sort(arr,mid+1,high);
			merge(arr,low,high,mid);
		}
		}

	private static void merge(int[] arr, int l, int r, int m) {
		// TODO Auto-generated method stub
		int n1 = m - l + 1;
        int n2 = r - m;

        
        int L[] = new int[n1];
        int R[] = new int[n2];

        
        for (int i = 0; i < n1; ++i)
            L[i] = arr[l + i];
        for (int j = 0; j < n2; ++j)
            R[j] = arr[m + 1 + j];

        
        int i = 0, j = 0;

       
        int k = l;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }

       
        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
        }

        
        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }
	}
	}

	
