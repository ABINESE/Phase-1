package assistedPractice4;

import java.util.ArrayList;
import java.util.Scanner;

public class BinarySearch {
	public static boolean binarySearch(int[] arr, int target) {
        int low = 0;
        int high = arr.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2; 
            int guess = arr[mid];

            if (guess == target) {
                return true; 
            } else if (guess < target) {
                low = mid + 1; 
            } else {
                high = mid - 1; 
            }
        }

   
        return false;
    }
public static void main(String[] args)
{
	Scanner scanner=new Scanner(System.in);
	System.out.print("Enter the number of elements");
	int n=scanner.nextInt();
	int[] arr=new int[n];
	System.out.print("Enter the elements");
	for(int i=0;i<n;i++)
	{
		arr[i]=scanner.nextInt();
	}
	
	System.out.print("Enter searching elements");
	int input=scanner.nextInt();
	
	
	if(binarySearch(arr,input))
		System.out.print(input+" is present in the array");
	else
		System.out.print(input+" is not present in the array");
		
	

}
}
