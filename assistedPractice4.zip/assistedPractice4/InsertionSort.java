package assistedPractice4;

import java.util.Scanner;

public class InsertionSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner=new Scanner(System.in);
		System.out.print("Enter the number of elements");
		int n=scanner.nextInt();
		int[] arr=new int[n];
		System.out.print("Enter the elements");
		for(int i=0;i<n;i++)
		{
			arr[i]=scanner.nextInt();
		}
		Sort(arr);
		System.out.print("Sorted arrays\n");
		for(int i=0;i<n;i++)
		{
			System.out.println(arr[i]);
		}
	}

	private static void Sort(int[] arr) {
		// TODO Auto-generated method stub
		  int n = arr.length;
	        for (int i = 1; i < n; ++i) {
	            int key = arr[i];
	            int j = i - 1;

	          
	            while (j >= 0 && arr[j] > key) {
	                arr[j + 1] = arr[j];
	                j = j - 1;
	            }
	            arr[j + 1] = key;
	        }
	}
	}


