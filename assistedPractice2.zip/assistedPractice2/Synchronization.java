package assistedPractice2;
class BankAccount{
	private int balance=0;
	public synchronized void deposit(int amount)
	{
		balance+=amount;
		System.out.println("The amount is deposited  , Balance is  " + balance);
	}
	public synchronized void withdraw(int amount)
	{
		if(balance<amount)
		{
			System.out.println("The amount is insufficient");
		}
		else
		{
			balance-=amount;
			System.out.println("The amount is withdrawed  , balance is "+ balance);
		}
	}
	public int getBalance() {
		return balance;
	}
	
}
public class Synchronization  {
public static void main(String[] args)
{
	BankAccount ba=new BankAccount();
	
	Thread ThreadDeposit=new Thread(()-> {
	ba.deposit(500);
	ba.deposit(200);});
	
	Thread ThreadWithdraw=new Thread(()->{
		ba.withdraw(300);
		ba.withdraw(200);
	});
	
	ThreadDeposit.start();
	ThreadWithdraw.start();
	try {
		ThreadDeposit.join();
		ThreadDeposit.join();
	}
	catch(Exception e)
	{
		System.out.print(e);
	}
	 System.out.println("Final Balance is: " + ba.getBalance());
}
}
