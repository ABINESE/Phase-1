package assistedPractice2;
import java.util.Scanner;
class InvalidEmailException extends Exception {
    public InvalidEmailException(String message) {
        super(message);
    }
}
public class Registration {
	public void validateEmail(String email) throws InvalidEmailException {
        if (email == null || !email.contains("@")) {
            throw new InvalidEmailException("Email is invalid.");
        }
    }

    public void registerUser(String username, int age, String email) {
        try {
            if (username == null || username.trim().isEmpty()) {
                throw new InvalidRegistrationException("Username cannot be empty.");
            }
            if (age < 18) {
                throw new InvalidRegistrationException("User must be at least 18 years old.");
            }
            
            validateEmail(email); 
            
            System.out.println("User registered successfully: " + username);
        } catch (InvalidRegistrationException | InvalidEmailException e) {
            System.out.println("Registration failed: " + e.getMessage());
        } finally {
            System.out.println("Registration process completed.");
        }
    }

    public static void main(String[] args) {
    	 Registration registration = new Registration();
        Scanner scanner=new Scanner(System.in);
        while(true)
        {
        	System.out.println("Enter the Name");
        	String name=scanner.next();
        	if(name.equalsIgnoreCase("Exit"))
        			{
        		break;
        			}
        	System.out.println("Enter the age");
        	int age=scanner.nextInt();
        	System.out.println("Enter the email");
        	String email=scanner.next();
        	registration.registerUser(name, age, email);
        }
        System.out.print("Program finished....");
    }
}
