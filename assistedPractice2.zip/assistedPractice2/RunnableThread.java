package assistedPractice2;

public class RunnableThread implements Runnable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        RunnableThread obj=new RunnableThread();
        Thread th=new Thread(obj);
         th.start();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<5;i++)
		{
			System.out.println("Thread is Executing...");
			try {Thread.sleep(3000);}
			catch(Exception e) {
				System.out.print(e);
			}
			//System.out.println(Thread.currentThread().getName());
		}
	}

}
