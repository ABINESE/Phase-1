package assistedPractice2;
interface InterfaceA {
    default void show() {
        System.out.println("Default method of InterfaceA");
    }
}

interface InterfaceB {
    default void show() {
        System.out.println("Default method of InterfaceB");
    }
}
public class DiamondSolutionClass implements InterfaceA, InterfaceB{
	@Override
    public void show() {
        InterfaceA.super.show(); 
        InterfaceB.super.show(); 
        System.out.println("Overridden method in DiamondSolutionClass");
    }

    public static void main(String[] args) {
        DiamondSolutionClass obj = new DiamondSolutionClass();
        obj.show();
    }
}
