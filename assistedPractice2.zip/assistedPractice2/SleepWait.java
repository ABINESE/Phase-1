package assistedPractice2;

public class SleepWait {
private static Object LOCK = new Object();
    
    public static void main(String[] args) throws InterruptedException {
        Thread sleepThread = new Thread(() -> {
            System.out.println("Sleeping Thread -> Going to sleep.");
            try {
                Thread.sleep(10000); 
                System.out.println("Sleeping Thread  -> Woke up and running again.");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        
        Thread waitThread = new Thread(() -> {
            synchronized(LOCK) {
                try {
                    System.out.println("Waiting Thread -> Going to wait.");
                    LOCK.wait(); 
                    System.out.println("Waiting Thread -> Notified and running again.");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        
        sleepThread.start(); 
        
        waitThread.start(); 
        Thread.sleep(500);
        synchronized(LOCK) {
            LOCK.notify();
        }
    }
}
