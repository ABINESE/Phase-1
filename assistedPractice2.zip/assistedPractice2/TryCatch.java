package assistedPractice2;
import java.util.Scanner;
public class TryCatch {
	public static void main(String[] args) {
        int a,b;
        Scanner scanner=new Scanner(System.in);
       
        try {
        	 System.out.println("Enter number 1");
             a=scanner.nextInt();
             System.out.println("Enter the number 2");
             b=scanner.nextInt();
            int result = a / b;
            System.out.println("Result: " + result);
        } catch (Exception e) {
            System.out.println("Exception is.  "+ e);
        } finally {
            System.out.println("This block always executes, regardless of an exception.");
        }
        
        System.out.println("Program continues after exception handling.");
    }
}
