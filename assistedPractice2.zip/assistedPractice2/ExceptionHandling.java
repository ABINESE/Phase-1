package assistedPractice2;
import java.util.InputMismatchException;
import java.util.Scanner;
public abstract class ExceptionHandling {
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        try {
	            System.out.print("Enter the first number: ");
	            int number1 = scanner.nextInt();
	            
	            System.out.print("Enter the second number: ");
	            int number2 = scanner.nextInt();
	            
	            int result = divide(number1, number2);
	            System.out.println("The result of division is: " + result);
	        } catch (ArithmeticException e) {
	            System.out.println("Error: Division by zero is not allowed.  " + e);
	        } catch (InputMismatchException e) {
	            System.out.println("Error: Please enter a valid integer.  "+e);
	        } finally {
	            System.out.println("Operation completed.");
	           
	        }
	    }

	    public static int divide(int num1, int num2) {
	        return num1 / num2; 
	    }
}
