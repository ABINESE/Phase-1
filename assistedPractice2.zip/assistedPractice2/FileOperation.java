package assistedPractice2;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
public class FileOperation {
public static void FileCreate(String name, String Content)
{
	try (FileWriter fileWriter=new FileWriter(name)){
	fileWriter.write(Content);
	 System.out.println("File written successfully.");
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	}
public static void FileRead(String name)
{
	try 
 (BufferedReader bufferReader=new BufferedReader(new FileReader(name));)	{
 String line;
 System.out.println("Content of " + name + ":");
 while((line=bufferReader.readLine())!=null)
 {
	 System.out.println(line);
 }

	}
	catch(Exception e)
	{
		 System.out.println(e);
	}
}

public static void FileUpdate(String name, String content)
{
	try ( FileWriter fileWriter=new FileWriter(name,false);)
	{
		fileWriter.write(content);
		 System.out.println("File updated successfully.");
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
}
public static void FileDelete(String name)
{
	try {
		Files.delete(Paths.get(name));
		 System.out.println("File deletedsuccessfully.");
	}
	catch(Exception e)
	{
		 System.out.println(e);
	}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      String name="sample.txt";
      FileCreate(name,"Hell World Java programming");
      FileRead(name);
      FileUpdate( name, "Data has been updated");
      //FileDelete(name);
      
      
	}}


