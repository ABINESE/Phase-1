package assistedPractice2;
              // ABSTRACTION AND ENCAPSULATION
abstract class Vehicle {
    private String make;
    private String model;

    public Vehicle(String make, String model) {
        this.make = make;
        this.model = model;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    
    public abstract void move();
}

                // INHERITANCE

class Car extends Vehicle {
    public Car(String make, String model) {
        super(make, model);
    }

    @Override
    public void move() {
        System.out.println(getMake() + " " + getModel() + " is driving.");
    }
}

class Bicycle extends Vehicle {
    public Bicycle(String make, String model) {
        super(make, model);
    }

    @Override
    public void move() {
        System.out.println(getMake() + " " + getModel() + " is cycling.");
    }
}
                     // POLYMORPHISM
public class OopsOperation {

	public static void main(String[] args) {
        Vehicle myCar = new Car("Toyota", "Corolla");
        Vehicle myBike = new Bicycle("Giant", "Escape 3");

        moveVehicle(myCar);
        moveVehicle(myBike);
    }

    public static void moveVehicle(Vehicle vehicle) {
        vehicle.move(); // 
    }
}
