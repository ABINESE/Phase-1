package assistedPractice2;

public class MyThread extends Thread {

	public void run()
	{
		for(int i=0;i<5;i++)
		{
		System.out.println("Thread is executing....");
		try {
			Thread.sleep(2000);
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     MyThread th=new MyThread();
     th.start();
	}

}
