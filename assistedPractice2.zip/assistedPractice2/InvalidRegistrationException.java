package assistedPractice2;

public class InvalidRegistrationException extends Exception {
	

	public InvalidRegistrationException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}
	
}
